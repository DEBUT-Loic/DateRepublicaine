function firstLetterUC(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function durateSpring(date) {
    return Math.round((summerSolstice(currentYear(date)) - springEquinox(currentYear(date))) / getOneDayInMS());
}
function durateSummer(date) {
    return Math.round((autumnEquinox(currentYear(date)) - summerSolstice(currentYear(date))) / getOneDayInMS());
}
function durateAutumn(date) {
    return Math.round((winterSolstice(currentYear(date)) - autumnEquinox(currentYear(date))) / getOneDayInMS());
}
function durateWinter(date) {
    return Math.round((springEquinox(currentYear(date) + 1) - winterSolstice(currentYear(date))) / getOneDayInMS());
}

function dateOfEaster(year) {
    var g,c,x,z,d,e,n, month,day;
    g = Math.floor(year % 19) + 1;
    c = Math.floor(year / 100) + 1;
    x = Math.floor((3 * c) / 4) - 12;
    z = Math.floor((8 * c + 5) / 25) - 5;
    d = Math.floor((5 * year) / 4) - x - 10;
    e = Math.floor(11 * g + 20 + z - x) % 30;
    if(e < 0) e += 30;
    if(((e == 25) && (g > 11)) || (e == 24)) e++;
    n = 44 - e;
    if(n < 21) n += 30;
    n = n + 7 - ((d + n) % 7);
    if(n > 31) {
       month = 4;
       day = n - 31;
    } else {
       month = 3;
       day = n;
    }

    return `${month < 10 ? "0"+month : month}-${day}`;
}

function fromJulian(jd) {
    const dateTemp = new Date((jd - 2440587.5) * 86400 * 1000);
    dateTemp.setHours(0,0,0);
    return dateTemp;
}

// Équinoxe de printemps (mars)
function springEquinox(year) {
    const Y = (year - 2000) / 1000;
    const JDE0 =
        2451623.80984 +
        365242.37404 * Y +
        0.05169 * Y * Y -
        0.00411 * Y * Y * Y -
        0.00057 * Y * Y * Y * Y;

    return fromJulian(JDE0);
}

// Solstice d'été (juin)
function summerSolstice(year) {
    const Y = (year - 2000) / 1000;
    const JDE0 =
        2451716.56767 +
        365241.62603 * Y +
        0.00325 * Y * Y +
        0.00888 * Y * Y * Y -
        0.00030 * Y * Y * Y * Y;

    return fromJulian(JDE0);
}

function autumnEquinox(year) {
    const Y = (year - 2000) / 1000;
    const JDE0 =
        2451810.217 +
        365242.01767 * Y -
        0.11575 * Y * Y +
        0.00337 * Y * Y * Y +
        0.00078 * Y * Y * Y * Y;

    // Retourner les composantes UTC
    return fromJulian(JDE0);
}

// Solstice d'hiver (décembre)
function winterSolstice(year) {
    const Y = (year - 2000) / 1000;
    const JDE0 =
        2451900.05952 +
        365242.74049 * Y -
        0.06223 * Y * Y -
        0.00823 * Y * Y * Y +
        0.00032 * Y * Y * Y * Y;

    return fromJulian(JDE0);
}

function multiple(nb) {
    let multipleTab = "1, ";

    for(let i=2; i<=nb; i++) {
        if(nb % i === 0) multipleTab += i+", ";
    }

    return multipleTab.slice(0, -2);
}

function calendar() {
    let startDate = new Date; // Albadi, 1er Univerne
    let startWeekDay = 0; // Albadi = 0
    let date = new Date;
    let season, seasonId;
    let durateMonthTab = [];

    let monthsReal = ["jan","fev","mars","avril","mai","juin","juil","aout","sept","oct","nov","dec"];

    const dateEaster = new Date(`${currentYear(date)}-${dateOfEaster(currentYear(date))}`);
    const tabDateEvent = ["01-01","05-01","05-08","07-14","08-15","11-01","11-11","12-25"];
	const tabEvent = ["Jour de l'An","Équinoxe de Printemps","Pâques","Lundi de Pâques","Fête du Travail","Victoire 1945","Ascension","Pentecôte","Lundi de Pentecôte","Solstice d'Été","Fête nationale","Assomption","Équinoxe d'Automne","Toussaint","Armistice 1918","Solstice d'Hiver","Noël"]

	tabDateEvent.push(dateOfEaster(currentYear(date)));

	// Lundi de Pâques
	let lundiPaques = new Date(dateEaster);
	lundiPaques.setDate(dateEaster.getDate() + 1);
	let lundiPaquesMois = parseInt(lundiPaques.getMonth()+1);
	tabDateEvent.push(`${lundiPaquesMois < 10 ? "0"+lundiPaquesMois : lundiPaquesMois}-${lundiPaques.getDate() < 10 ? "0"+lundiPaques.getDate() : lundiPaques.getDate()}`);

	// Jeudi de l'Ascension
	let jeudiAscension = new Date(dateEaster);
	jeudiAscension.setDate(dateEaster.getDate() + 39);
	let jeudiAscensionMois = parseInt(jeudiAscension.getMonth()+1);
	tabDateEvent.push(`${jeudiAscensionMois < 10 ? "0"+jeudiAscensionMois : jeudiAscensionMois}-${jeudiAscension.getDate() < 10 ? "0"+jeudiAscension.getDate() : jeudiAscension.getDate()}`);

	// Lundi de Pentecôte
	let lundiPentecote = new Date(dateEaster);
	lundiPentecote.setDate(dateEaster.getDate() + 50);
	let lundiPentecoteMois = parseInt(lundiPentecote.getMonth()+1);
	tabDateEvent.push(`${lundiPentecoteMois < 10 ? "0"+lundiPentecoteMois : lundiPentecoteMois}-${lundiPentecote.getDate() < 10 ? "0"+lundiPentecote.getDate() : lundiPentecote.getDate()}`);
	
	// Pentecôte
	let pentecote = new Date(lundiPentecote);
	pentecote.setDate(lundiPentecote.getDate() - 1);
	let pentecoteMois = parseInt(pentecote.getMonth()+1);
	tabDateEvent.push(`${pentecoteMois < 10 ? "0"+pentecoteMois : pentecoteMois}-${pentecote.getDate() < 10 ? "0"+pentecote.getDate() : pentecote.getDate()}`);

    // Printemps
    let printemps = new Date(springEquinox(currentYear(date)));
    let printempsMois = parseInt(printemps.getMonth()+1);
    tabDateEvent.push(`${printempsMois < 10 ? "0"+printempsMois : printempsMois}-${printemps.getDate() < 10 ? "0"+printemps.getDate() : printemps.getDate()}`);

    // Été
    let ete = new Date(springEquinox(currentYear(date)));
    ete.setDate(printemps.getDate() + durateSpring(date));
    let eteMois = parseInt(ete.getMonth()+1);
    tabDateEvent.push(`${eteMois < 10 ? "0"+eteMois : eteMois}-${ete.getDate() < 10 ? "0"+ete.getDate() : ete.getDate()}`);

    // Automne
    let automne = new Date(springEquinox(currentYear(date)));
    automne.setDate(printemps.getDate() + durateSpring(date) + durateSummer(date));
    let automneMois = parseInt(automne.getMonth()+1);
    tabDateEvent.push(`${automneMois < 10 ? "0"+automneMois : automneMois}-${automne.getDate() < 10 ? "0"+automne.getDate() : automne.getDate()}`);

    // Hiver
    let hiver = new Date(springEquinox(currentYear(date)));
    hiver.setDate(printemps.getDate() + durateSpring(date) + durateSummer(date) + durateAutumn(date));
    let hiverMois = parseInt(hiver.getMonth()+1);
    tabDateEvent.push(`${hiverMois < 10 ? "0"+hiverMois : hiverMois}-${hiver.getDate() < 10 ? "0"+hiver.getDate() : hiver.getDate()}`);

	tabDateEvent.sort((a, b) => {
		let [ma, da] = a.split('-').map(Number);
		let [mb, db] = b.split('-').map(Number);
		return ma - mb || da - db;
	});

    for (let i = 0; i < jsonDate.months.length; i++) {
        let daysHTML = "";
		let numDaysHTML = "";

        let spring = durateSpring(date);
        let summer = durateSummer(date);
        let autumn = durateAutumn(date);
        let winter = durateWinter(date);

        if(i < 3) {
            season = spring;
            seasonId = "printemps"
        }
        else if(i < 6) {
            season = summer;
            seasonId = "ete"
        }
        else if(i < 9) {
            season = autumn;
            seasonId = "automne"
        }
        else {
            season = winter;
            seasonId = "hiver"
        }

        if(i % 3 == 0) durateMonthTab.push(Math.floor(season / 3));
        else if(i % 3 == 1) durateMonthTab.push(Math.floor((season - durateMonthTab[durateMonthTab.length - 1]) / 2));
        else durateMonthTab.push((season - durateMonthTab[durateMonthTab.length - 2] - durateMonthTab[durateMonthTab.length - 1]));

        // Générations des noms de jours
        for (let d = 0; d < jsonDate.days.length; d++) {
			daysHTML += "<th>" + firstLetterUC(jsonDate.days[d]) + "</th>";
		}

        // Génération des numéros de jour avec décalage selon le premier jour
        numDaysHTML += `<tr> ${startWeekDay > 0 ? "<td colspan="+startWeekDay+" class=\"empty\" ></td>" : ""}`;

        for (let j = 1; j <= durateMonthTab[i]; j++) {
            numDaysHTML += "<td class=\"num\">" + j + "</td>";

            // Passage à la ligne tous les 7 jours
            if ((startWeekDay + j) % 7 === 0 && j !== durateMonthTab[i]) {
                numDaysHTML += "</tr><tr>";
            }
        }
        numDaysHTML += "</tr>";

        // Calcul du jour de la semaine du mois suivant
        startWeekDay = (startWeekDay + durateMonthTab[i]) % 7;

        let displayConst = `
			<table id="${seasonId}" data-mois="${jsonDate.months[i]}">
				<thead>
					<tr>
						<th scope="col" colspan="7">${firstLetterUC(jsonDate.months[i])}</th>
					</tr>
				</thead>

				<tbody>
					<tr>
						${daysHTML}
					</tr>
					<tr>
						${numDaysHTML}
					</tr>
				</tbody>
			</table>
		`;

        $("#calendar").append(displayConst);
    }

    $.each(tabDateEvent, function(index,elem) {
        let dateEvent = new Date(`${currentYear(date)}-${elem}`);

        let dateReal = new Date(springEquinox(currentYear(date)));
        dateReal.setDate(springEquinox(currentYear(date)).getDate() + dayOfYear(dateEvent) - 1);
        let dateRealText = `${dateReal.getDate()} ${monthsReal[dateReal.getMonth()]}`;

        let tempTdVal = $("#calendar td.num").eq(dayOfYear(dateEvent) - 1).text();

        $("#calendar td.num").eq(dayOfYear(dateEvent) - 1).text("").addClass("evenement").append(`
                <div class="flip-inner">
                    <div class="flip-front">${tempTdVal} <small>${dateRealText}</small></div>  <!-- recto : date -->
                    <div class="flip-back">${tabEvent[index]}</div> <!-- verso : événement -->
                </div>
            `);
        
        if(dayOfYear(dateEvent)-1 == 0 || dayOfYear(dateEvent)-1 == durateSpring(date) || dayOfYear(dateEvent)-1 == durateSpring(date)+durateSummer(date) || dayOfYear(dateEvent)-1 == durateSpring(date)+durateSummer(date)+durateAutumn(date)) {
            $("#calendar td.num").eq(dayOfYear(dateEvent)-1).addClass("premier");
        }
    })

    $("#calendar td.num").each(function(i, elem) {
        if(!$(elem).hasClass("evenement")) {
            let dateReal = new Date(springEquinox(currentYear(date)));
            dateReal.setDate(springEquinox(currentYear(date)).getDate() + i);

            let dateRealText = `${dateReal.getDate()} ${monthsReal[dateReal.getMonth()]}`;

            $(elem).html($(elem).text() + "<small>" + dateRealText + "</small>");
        }
    })

    $("#calendar td.num").eq(dayOfYear(date) - 1).addClass("actuel");
}