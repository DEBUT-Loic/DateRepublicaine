var jsonDate;

$(document).ready(() => {
    $.ajax({
        url: "json/data.json",
        dataType: "json",
        async: false,
        success: (res) => {
            jsonDate = res;
        }
    })

    calendar();
})