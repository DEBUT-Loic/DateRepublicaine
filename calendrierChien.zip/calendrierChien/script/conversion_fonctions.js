function currentYear(date) {
    return date < springEquinox(date.getFullYear()) ? date.getFullYear() - 1 : date.getFullYear();
}
function getOneDayInMS() {
	return 1000 * 60 * 60 * 24;
}

function month(date) {
    return Math.floor((dayOfYear(date) - 1) / 30) + 1;
}

function monthName(date) {
    return jsonDate.months[month(date) - 1];
}

function dayOfYear(date) {
    const firstDayOfYear = springEquinox(currentYear(date));
    return Math.floor((date - firstDayOfYear) / getOneDayInMS())+1;
}

function dayOfMonth(date) {
    return ((dayOfYear(date) - 1) - (month(date) - 1) * 30) + 1;
}

function dayOfWeek(date) {
    return ((dayOfMonth(date) - 1) % 7) + 1;
}

function dayOfWeekName(date) {
    return jsonDate.days[dayOfWeek(date) - 1];
}