var jsonDate;

$(document).ready(() => {
    $.ajax({
        url: "json/data.json",
        dataType: "json",
        async: false,
        success: (res) => {
            jsonDate = res;
        }
    })

    // 1er jour du calendrier solaire = 21 mars 1583 (1er équinoxe de printemps du calendrier grégorien)

    console.log(springEquinox(2025))
    console.log(summerSolstice(2025))
    console.log(autumnEquinox(2025))
    console.log(winterSolstice(2025))

    calendar();
})